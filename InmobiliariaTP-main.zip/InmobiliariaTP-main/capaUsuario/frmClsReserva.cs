﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;


namespace capaUsuario
{
    public partial class frmClsReserva : Form
    {
        private Inmobiliaria inmoCasa;
        private Inmobiliaria inmoDpto;
        private Inmobiliaria inmoCli;
        private Inmobiliaria inmoReserva;
        private Reserva reserva;

        public frmClsReserva()
        {
            InitializeComponent();
            inmoCasa = Inmobiliaria.Recuperar("Casa.dat");
            inmoDpto = Inmobiliaria.Recuperar("Departamento.dat");
            inmoCli = Inmobiliaria.Recuperar("Cliente.dat");
            inmoReserva = Inmobiliaria.Recuperar("Reserva.dat");            

            //ClearEstados();

            //Cargar List
            CargarCompView();
        }
        private void ClearEstados()
        {
            for (var i = 0; i < inmoCasa.Casas.Count; i++)
            {
               inmoCasa.Casas[i].Estado = " ";
            }

            for (var j = 0; j < inmoDpto.Dptos.Count; j++)
            {
                inmoDpto.Dptos[j].Estado = " ";
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            Cliente cli = (Cliente)listBoxClientes.SelectedItem;
            Casa cas = (Casa)listBoxCasas.SelectedItem;

            if (cli != null && cas != null)
            {
                cas.Estado = "R";//Guardo el estado RESERVA de la casa
                try
                {
                    reserva = new Reserva(DateTime.Today,inmoReserva.Reserva.Count+1,cas,null,cli,45);
                    inmoReserva.AgregarReserva(reserva);
                    inmoReserva.guardarReserva();
                    inmoCasa.guardarCasa();                    

                    MessageBox.Show("Se Registro la reserva");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

                //Cargar List y DataView.
                CargarCompView();
            }
            else
                MessageBox.Show("No selecciono un Cliente o Casa");
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Cliente cli = (Cliente)listBoxClientes.SelectedItem;
            Dpto dp = (Dpto)listBoxDptos.SelectedItem;

            if (cli != null && dp != null)
            {
                dp.Estado = "R";//Guardo el estado RESERVA del dpto
                try
                {
                    reserva = new Reserva(DateTime.Today, inmoReserva.Reserva.Count + 1, null, dp, cli, 45);
                    inmoReserva.AgregarReserva(reserva);
                    inmoReserva.guardarReserva();
                    inmoDpto.guardarDepartamento();
                    
                    MessageBox.Show("Se Registro la reserva");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                
                //Cargar List y DataView.
                CargarCompView();
            }
            else
                MessageBox.Show("No selecciono un Cliente o Dpto");
        }
        //Eliminar Reserva
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            Reserva r = (Reserva)lstTablaReserva.SelectedItem;

            if (r != null)
            {
                Casa cr = (Casa)r.CasaReserva;
                Dpto dr = (Dpto)r.DptoReserva;
                if (cr != null)
                {
                    cr.Estado = null;//Elimino el estado de reserva
                    inmoCasa.guardarCasa();
                }
                if (dr != null)
                {
                    dr.Estado = null;//Elimino el estado de reserva
                    inmoDpto.guardarDepartamento();
                }
                inmoReserva.EliminarReserva(r);
                //y actualizo guardando la tabla
                inmoReserva.guardarReserva();

                //Cargar List y DataView.
                CargarCompView();
            }
            else
                MessageBox.Show("No selecciono una Reserva.");
        }
        private void CargarCompView()
        {
            //Selecciona departamentos disponibles. Estado <> 'R'.
            Inmobiliaria dptoReservada = new Inmobiliaria("inmo");
            for (var i = 0; i < inmoDpto.Dptos.Count; i++)
            {
                Dpto d = inmoDpto.Dptos[i];
                if (d.Estado == "" || d.Estado == null) //Verificar.
                    dptoReservada.agregarDpto(d);
            }
            //Cargar ListBox Dpto
            listBoxDptos.DataSource = null;
            listBoxDptos.DataSource = dptoReservada.Dptos;
            listBoxDptos.ClearSelected();

            //Selecciona casas disponibles. Estado <> 'R'.
            Inmobiliaria casaReservada = new Inmobiliaria("inmo");
            for (var i = 0; i < inmoCasa.Casas.Count; i++)
            {
                Casa c = inmoCasa.Casas[i];
                if (c.Estado == "" || c.Estado == null) //Verificar.    
                    casaReservada.agregarCasa(c);
            }
            //Cargar listBox Casas
            listBoxCasas.DataSource = null;
            listBoxCasas.DataSource = casaReservada.Casas;
            listBoxCasas.ClearSelected();

            //Cargar ListBox Reservas
            lstTablaReserva.DataSource = null;
            lstTablaReserva.DataSource = inmoReserva.Reserva;
            lstTablaReserva.ClearSelected();

            //Cargar ListBox Clientes
            listBoxClientes.DataSource = null;
            listBoxClientes.DataSource = inmoCli.ListaClientes;
            listBoxClientes.ClearSelected();
        }
    }
}
