﻿
namespace capaUsuario
{
    partial class frmClsDpto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxDpto = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxPiso = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxTotalM2 = new System.Windows.Forms.TextBox();
            this.textBoxProvincia = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxPartido = new System.Windows.Forms.TextBox();
            this.textBoxLocalidad = new System.Windows.Forms.TextBox();
            this.textBoxNumero = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxCalle = new System.Windows.Forms.TextBox();
            this.buttonCancelar = new System.Windows.Forms.Button();
            this.botAgregar = new System.Windows.Forms.Button();
            this.txtId = new System.Windows.Forms.TextBox();
            this.lblIdDpto = new System.Windows.Forms.Label();
            this.butActualizarCasa = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(767, 127);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 25);
            this.label7.TabIndex = 56;
            this.label7.Text = "Dpto";
            // 
            // textBoxDpto
            // 
            this.textBoxDpto.Location = new System.Drawing.Point(855, 129);
            this.textBoxDpto.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxDpto.Name = "textBoxDpto";
            this.textBoxDpto.Size = new System.Drawing.Size(63, 22);
            this.textBoxDpto.TabIndex = 55;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(587, 127);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 25);
            this.label6.TabIndex = 54;
            this.label6.Text = "Piso";
            // 
            // textBoxPiso
            // 
            this.textBoxPiso.Location = new System.Drawing.Point(647, 127);
            this.textBoxPiso.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPiso.Name = "textBoxPiso";
            this.textBoxPiso.Size = new System.Drawing.Size(61, 22);
            this.textBoxPiso.TabIndex = 53;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(85, 334);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 25);
            this.label9.TabIndex = 52;
            this.label9.Text = "Total M2";
            // 
            // textBoxTotalM2
            // 
            this.textBoxTotalM2.Location = new System.Drawing.Point(247, 334);
            this.textBoxTotalM2.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxTotalM2.Name = "textBoxTotalM2";
            this.textBoxTotalM2.Size = new System.Drawing.Size(124, 22);
            this.textBoxTotalM2.TabIndex = 51;
            // 
            // textBoxProvincia
            // 
            this.textBoxProvincia.Location = new System.Drawing.Point(247, 276);
            this.textBoxProvincia.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxProvincia.Name = "textBoxProvincia";
            this.textBoxProvincia.Size = new System.Drawing.Size(261, 22);
            this.textBoxProvincia.TabIndex = 50;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(85, 276);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(92, 25);
            this.label8.TabIndex = 49;
            this.label8.Text = "Provincia";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(85, 228);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 25);
            this.label5.TabIndex = 48;
            this.label5.Text = "Partido";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(85, 178);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 25);
            this.label4.TabIndex = 47;
            this.label4.Text = "Localidad";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(85, 127);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 25);
            this.label3.TabIndex = 46;
            this.label3.Text = "Numero";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(85, 78);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 25);
            this.label2.TabIndex = 45;
            this.label2.Text = "Calle";
            // 
            // textBoxPartido
            // 
            this.textBoxPartido.Location = new System.Drawing.Point(247, 228);
            this.textBoxPartido.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxPartido.Name = "textBoxPartido";
            this.textBoxPartido.Size = new System.Drawing.Size(253, 22);
            this.textBoxPartido.TabIndex = 44;
            // 
            // textBoxLocalidad
            // 
            this.textBoxLocalidad.Location = new System.Drawing.Point(247, 178);
            this.textBoxLocalidad.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxLocalidad.Name = "textBoxLocalidad";
            this.textBoxLocalidad.Size = new System.Drawing.Size(253, 22);
            this.textBoxLocalidad.TabIndex = 43;
            // 
            // textBoxNumero
            // 
            this.textBoxNumero.Location = new System.Drawing.Point(247, 127);
            this.textBoxNumero.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxNumero.Name = "textBoxNumero";
            this.textBoxNumero.Size = new System.Drawing.Size(253, 22);
            this.textBoxNumero.TabIndex = 42;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 39);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 17);
            this.label1.TabIndex = 41;
            this.label1.Text = "DIRECCION";
            // 
            // textBoxCalle
            // 
            this.textBoxCalle.Location = new System.Drawing.Point(247, 78);
            this.textBoxCalle.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxCalle.Name = "textBoxCalle";
            this.textBoxCalle.Size = new System.Drawing.Size(253, 22);
            this.textBoxCalle.TabIndex = 40;
            // 
            // buttonCancelar
            // 
            this.buttonCancelar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCancelar.Location = new System.Drawing.Point(669, 442);
            this.buttonCancelar.Margin = new System.Windows.Forms.Padding(4);
            this.buttonCancelar.Name = "buttonCancelar";
            this.buttonCancelar.Size = new System.Drawing.Size(140, 48);
            this.buttonCancelar.TabIndex = 58;
            this.buttonCancelar.Text = "Cancelar";
            this.buttonCancelar.UseVisualStyleBackColor = true;
            this.buttonCancelar.Click += new System.EventHandler(this.buttonCancelar_Click);
            // 
            // botAgregar
            // 
            this.botAgregar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.botAgregar.Location = new System.Drawing.Point(428, 442);
            this.botAgregar.Margin = new System.Windows.Forms.Padding(4);
            this.botAgregar.Name = "botAgregar";
            this.botAgregar.Size = new System.Drawing.Size(137, 48);
            this.botAgregar.TabIndex = 57;
            this.botAgregar.Text = "Agregar";
            this.botAgregar.UseVisualStyleBackColor = true;
            this.botAgregar.Click += new System.EventHandler(this.botAgregar_Click);
            // 
            // txtId
            // 
            this.txtId.Enabled = false;
            this.txtId.Location = new System.Drawing.Point(247, 391);
            this.txtId.Margin = new System.Windows.Forms.Padding(4);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(112, 22);
            this.txtId.TabIndex = 60;
            // 
            // lblIdDpto
            // 
            this.lblIdDpto.AutoSize = true;
            this.lblIdDpto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIdDpto.Location = new System.Drawing.Point(86, 391);
            this.lblIdDpto.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIdDpto.Name = "lblIdDpto";
            this.lblIdDpto.Size = new System.Drawing.Size(80, 25);
            this.lblIdDpto.TabIndex = 59;
            this.lblIdDpto.Text = "Id Dpto:";
            // 
            // butActualizarCasa
            // 
            this.butActualizarCasa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butActualizarCasa.Location = new System.Drawing.Point(428, 445);
            this.butActualizarCasa.Margin = new System.Windows.Forms.Padding(4);
            this.butActualizarCasa.Name = "butActualizarCasa";
            this.butActualizarCasa.Size = new System.Drawing.Size(137, 43);
            this.butActualizarCasa.TabIndex = 61;
            this.butActualizarCasa.Text = "Actualizar";
            this.butActualizarCasa.UseVisualStyleBackColor = true;
            this.butActualizarCasa.Click += new System.EventHandler(this.butActualizarCasa_Click);
            // 
            // frmClsDpto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.Controls.Add(this.butActualizarCasa);
            this.Controls.Add(this.txtId);
            this.Controls.Add(this.lblIdDpto);
            this.Controls.Add(this.buttonCancelar);
            this.Controls.Add(this.botAgregar);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBoxDpto);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.textBoxPiso);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textBoxTotalM2);
            this.Controls.Add(this.textBoxProvincia);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxPartido);
            this.Controls.Add(this.textBoxLocalidad);
            this.Controls.Add(this.textBoxNumero);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxCalle);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmClsDpto";
            this.Text = "frmClsDpto";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxDpto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxPiso;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxTotalM2;
        private System.Windows.Forms.TextBox textBoxProvincia;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBoxPartido;
        private System.Windows.Forms.TextBox textBoxLocalidad;
        private System.Windows.Forms.TextBox textBoxNumero;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox textBoxCalle;
        private System.Windows.Forms.Button buttonCancelar;
        private System.Windows.Forms.Button botAgregar;
        private System.Windows.Forms.TextBox txtId;
        private System.Windows.Forms.Label lblIdDpto;
        private System.Windows.Forms.Button butActualizarCasa;
    }
}