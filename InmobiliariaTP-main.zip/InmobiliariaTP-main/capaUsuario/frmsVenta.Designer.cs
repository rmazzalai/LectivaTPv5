﻿
namespace capaUsuario
{
    partial class frmclsVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlAcceso = new System.Windows.Forms.Panel();
            this.lstTablaD = new System.Windows.Forms.ListBox();
            this.dtgViewTablaD = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.lstTablaC = new System.Windows.Forms.ListBox();
            this.dtgViewTablaC = new System.Windows.Forms.DataGridView();
            this.pnlAcceso.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaC)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlAcceso
            // 
            this.pnlAcceso.BackColor = System.Drawing.Color.DarkGray;
            this.pnlAcceso.Controls.Add(this.lstTablaD);
            this.pnlAcceso.Controls.Add(this.dtgViewTablaD);
            this.pnlAcceso.Controls.Add(this.btnClose);
            this.pnlAcceso.Controls.Add(this.lstTablaC);
            this.pnlAcceso.Controls.Add(this.dtgViewTablaC);
            this.pnlAcceso.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAcceso.Location = new System.Drawing.Point(0, 0);
            this.pnlAcceso.Margin = new System.Windows.Forms.Padding(4);
            this.pnlAcceso.Name = "pnlAcceso";
            this.pnlAcceso.Size = new System.Drawing.Size(1420, 737);
            this.pnlAcceso.TabIndex = 1;
            // 
            // lstTablaD
            // 
            this.lstTablaD.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaD.FormattingEnabled = true;
            this.lstTablaD.ItemHeight = 22;
            this.lstTablaD.Location = new System.Drawing.Point(736, 390);
            this.lstTablaD.Name = "lstTablaD";
            this.lstTablaD.Size = new System.Drawing.Size(268, 268);
            this.lstTablaD.TabIndex = 44;
            // 
            // dtgViewTablaD
            // 
            this.dtgViewTablaD.AllowUserToOrderColumns = true;
            this.dtgViewTablaD.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaD.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaD.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dtgViewTablaD.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaD.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaD.DefaultCellStyle = dataGridViewCellStyle1;
            this.dtgViewTablaD.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaD.Enabled = false;
            this.dtgViewTablaD.Location = new System.Drawing.Point(42, 390);
            this.dtgViewTablaD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaD.Name = "dtgViewTablaD";
            this.dtgViewTablaD.ReadOnly = true;
            this.dtgViewTablaD.RowHeadersWidth = 51;
            this.dtgViewTablaD.RowTemplate.Height = 28;
            this.dtgViewTablaD.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaD.Size = new System.Drawing.Size(688, 266);
            this.dtgViewTablaD.TabIndex = 43;
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.FlatAppearance.BorderSize = 0;
            this.btnClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClose.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.White;
            this.btnClose.Location = new System.Drawing.Point(22, 679);
            this.btnClose.Margin = new System.Windows.Forms.Padding(4);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(208, 48);
            this.btnClose.TabIndex = 41;
            this.btnClose.Text = "Salir y Almacenar";
            this.btnClose.UseVisualStyleBackColor = false;
            // 
            // lstTablaC
            // 
            this.lstTablaC.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaC.FormattingEnabled = true;
            this.lstTablaC.ItemHeight = 22;
            this.lstTablaC.Location = new System.Drawing.Point(736, 79);
            this.lstTablaC.Name = "lstTablaC";
            this.lstTablaC.Size = new System.Drawing.Size(268, 268);
            this.lstTablaC.TabIndex = 40;
            // 
            // dtgViewTablaC
            // 
            this.dtgViewTablaC.AllowUserToOrderColumns = true;
            this.dtgViewTablaC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaC.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaC.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dtgViewTablaC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaC.DefaultCellStyle = dataGridViewCellStyle2;
            this.dtgViewTablaC.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaC.Enabled = false;
            this.dtgViewTablaC.Location = new System.Drawing.Point(42, 79);
            this.dtgViewTablaC.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaC.Name = "dtgViewTablaC";
            this.dtgViewTablaC.ReadOnly = true;
            this.dtgViewTablaC.RowHeadersWidth = 51;
            this.dtgViewTablaC.RowTemplate.Height = 28;
            this.dtgViewTablaC.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaC.Size = new System.Drawing.Size(688, 270);
            this.dtgViewTablaC.TabIndex = 39;
            // 
            // frmclsVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1420, 737);
            this.Controls.Add(this.pnlAcceso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmclsVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Operaciones: Venta de Inmuebles";
            this.pnlAcceso.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaC)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAcceso;
        private System.Windows.Forms.ListBox lstTablaD;
        private System.Windows.Forms.DataGridView dtgViewTablaD;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.ListBox lstTablaC;
        private System.Windows.Forms.DataGridView dtgViewTablaC;
    }
}