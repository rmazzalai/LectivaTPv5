﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using capaNegocio;

namespace capaUsuario
{
    public partial class frmClsDpto : Form
    {
        private Dpto dpto;
        private int cant;

        public frmClsDpto(Dpto d, bool b, int cantdpto)
        {
            InitializeComponent();
            if (b)
            {
                butActualizarCasa.Enabled = true;
                botAgregar.Enabled = false;
                botAgregar.Visible = false;
            }
            else
            {
                butActualizarCasa.Enabled = false;
                butActualizarCasa.Visible = false;
                botAgregar.Enabled = true;
            }
            if (d != null)
            {
                cargarDpto(d);
            }
            else
            {
                dpto = d;                
                txtId.Enabled = false;
                cant = cantdpto + 1;
                txtId.Text = "DP-" + cant;
            }
        }
        public Dpto DptoReturn
        {
            get { return this.dpto; }
        }
        private void cargarDpto(Dpto d)
        {
            try
            {
                this.textBoxCalle.Text = d.Calle;
                this.textBoxNumero.Text = d.Nro.ToString();
                this.textBoxLocalidad.Text = d.Localidad;
                this.textBoxPartido.Text = d.Partido;
                this.textBoxProvincia.Text = d.Provincia;
                this.textBoxTotalM2.Text = d.M2Cubiertos.ToString();
                this.textBoxPiso.Text = d.NroPiso.ToString();
                this.textBoxDpto.Text = d.NroDpto.ToString();
                this.txtId.Text = d.Id;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void botAgregar_Click(object sender, EventArgs e)
        {
            string calle = this.textBoxCalle.Text;
            int nro = int.Parse(this.textBoxNumero.Text);
            string localidad = this.textBoxLocalidad.Text;
            string partido = this.textBoxPartido.Text;
            string provincia = this.textBoxProvincia.Text;
            int m2 = int.Parse(this.textBoxTotalM2.Text);
            int p = int.Parse(this.textBoxPiso.Text);
            string d = this.textBoxDpto.Text;
            string id = this.txtId.Text;

            dpto = new Dpto(calle, nro, localidad, partido, provincia,m2, p, d, id);

            this.Close();
        }
        private void butActualizarCasa_Click(object sender, EventArgs e)
        {
            dpto.Calle = this.textBoxCalle.Text;
            dpto.Nro = int.Parse(this.textBoxNumero.Text);
            dpto.Localidad = this.textBoxLocalidad.Text;
            dpto.Partido = this.textBoxPartido.Text;
            dpto.Provincia = this.textBoxProvincia.Text;            
            dpto.M2Cubiertos = int.Parse(this.textBoxTotalM2.Text);
            dpto.NroPiso = int.Parse(this.textBoxPiso.Text);
            dpto.NroDpto = this.textBoxDpto.Text;
            dpto.Id = this.txtId.Text;

            this.Close();
        }
        private void buttonCancelar_Click(object sender, EventArgs e)
        {
            dpto = null;
            this.Close();
        }


    }
}
