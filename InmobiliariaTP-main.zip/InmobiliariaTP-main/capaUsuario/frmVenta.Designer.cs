﻿
namespace capaUsuario
{
    partial class frmVenta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.pnlAcceso = new System.Windows.Forms.Panel();
            this.lstTablaOper = new System.Windows.Forms.ListBox();
            this.lstTablaR = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lblReservasC = new System.Windows.Forms.Label();
            this.btnEliminarOper = new System.Windows.Forms.Button();
            this.butSalir = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblOperV = new System.Windows.Forms.Label();
            this.lblTituloV = new System.Windows.Forms.Label();
            this.lstTablaO = new System.Windows.Forms.ListBox();
            this.dtgViewTablaO = new System.Windows.Forms.DataGridView();
            this.grpOper2 = new System.Windows.Forms.GroupBox();
            this.btnVenderDpto = new System.Windows.Forms.Button();
            this.grpOper1 = new System.Windows.Forms.GroupBox();
            this.btnVentaCasa = new System.Windows.Forms.Button();
            this.lstTablaD = new System.Windows.Forms.ListBox();
            this.lstTablaC = new System.Windows.Forms.ListBox();
            this.lblComision = new System.Windows.Forms.Label();
            this.pnlAcceso.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaO)).BeginInit();
            this.grpOper2.SuspendLayout();
            this.grpOper1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlAcceso
            // 
            this.pnlAcceso.BackColor = System.Drawing.Color.DarkGray;
            this.pnlAcceso.Controls.Add(this.lblComision);
            this.pnlAcceso.Controls.Add(this.lstTablaOper);
            this.pnlAcceso.Controls.Add(this.lstTablaR);
            this.pnlAcceso.Controls.Add(this.label3);
            this.pnlAcceso.Controls.Add(this.lblReservasC);
            this.pnlAcceso.Controls.Add(this.btnEliminarOper);
            this.pnlAcceso.Controls.Add(this.butSalir);
            this.pnlAcceso.Controls.Add(this.label2);
            this.pnlAcceso.Controls.Add(this.label1);
            this.pnlAcceso.Controls.Add(this.lblOperV);
            this.pnlAcceso.Controls.Add(this.lblTituloV);
            this.pnlAcceso.Controls.Add(this.lstTablaO);
            this.pnlAcceso.Controls.Add(this.dtgViewTablaO);
            this.pnlAcceso.Controls.Add(this.grpOper2);
            this.pnlAcceso.Controls.Add(this.grpOper1);
            this.pnlAcceso.Controls.Add(this.lstTablaD);
            this.pnlAcceso.Controls.Add(this.lstTablaC);
            this.pnlAcceso.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlAcceso.Location = new System.Drawing.Point(0, 0);
            this.pnlAcceso.Margin = new System.Windows.Forms.Padding(4);
            this.pnlAcceso.Name = "pnlAcceso";
            this.pnlAcceso.Size = new System.Drawing.Size(1576, 815);
            this.pnlAcceso.TabIndex = 1;
            // 
            // lstTablaOper
            // 
            this.lstTablaOper.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaOper.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaOper.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lstTablaOper.FormattingEnabled = true;
            this.lstTablaOper.ItemHeight = 20;
            this.lstTablaOper.Location = new System.Drawing.Point(42, 701);
            this.lstTablaOper.Name = "lstTablaOper";
            this.lstTablaOper.Size = new System.Drawing.Size(1103, 44);
            this.lstTablaOper.TabIndex = 63;
            // 
            // lstTablaR
            // 
            this.lstTablaR.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaR.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaR.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lstTablaR.FormattingEnabled = true;
            this.lstTablaR.ItemHeight = 20;
            this.lstTablaR.Location = new System.Drawing.Point(42, 342);
            this.lstTablaR.Name = "lstTablaR";
            this.lstTablaR.Size = new System.Drawing.Size(1529, 44);
            this.lstTablaR.TabIndex = 62;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkGray;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label3.Location = new System.Drawing.Point(791, 318);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(233, 25);
            this.label3.TabIndex = 61;
            this.label3.Text = "Reservas\\Departamentos";
            // 
            // lblReservasC
            // 
            this.lblReservasC.AutoSize = true;
            this.lblReservasC.BackColor = System.Drawing.Color.DarkGray;
            this.lblReservasC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblReservasC.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblReservasC.Location = new System.Drawing.Point(37, 314);
            this.lblReservasC.Name = "lblReservasC";
            this.lblReservasC.Size = new System.Drawing.Size(157, 25);
            this.lblReservasC.TabIndex = 60;
            this.lblReservasC.Text = "Reservas\\Casas";
            // 
            // btnEliminarOper
            // 
            this.btnEliminarOper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnEliminarOper.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEliminarOper.FlatAppearance.BorderSize = 0;
            this.btnEliminarOper.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnEliminarOper.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEliminarOper.Font = new System.Drawing.Font("Tahoma", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminarOper.ForeColor = System.Drawing.Color.White;
            this.btnEliminarOper.Location = new System.Drawing.Point(998, 621);
            this.btnEliminarOper.Margin = new System.Windows.Forms.Padding(4);
            this.btnEliminarOper.Name = "btnEliminarOper";
            this.btnEliminarOper.Size = new System.Drawing.Size(152, 44);
            this.btnEliminarOper.TabIndex = 57;
            this.btnEliminarOper.Text = "Eliminar Oper.";
            this.btnEliminarOper.UseVisualStyleBackColor = false;
            this.btnEliminarOper.Click += new System.EventHandler(this.btnEliminarOper_Click);
            // 
            // butSalir
            // 
            this.butSalir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.butSalir.Location = new System.Drawing.Point(1407, 701);
            this.butSalir.Margin = new System.Windows.Forms.Padding(4);
            this.butSalir.Name = "butSalir";
            this.butSalir.Size = new System.Drawing.Size(156, 43);
            this.butSalir.TabIndex = 55;
            this.butSalir.Text = "Salir";
            this.butSalir.UseCompatibleTextRendering = true;
            this.butSalir.UseVisualStyleBackColor = true;
            this.butSalir.Click += new System.EventHandler(this.butSalir_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkGray;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label2.Location = new System.Drawing.Point(791, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(177, 29);
            this.label2.TabIndex = 52;
            this.label2.Text = "Departamentos";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkGray;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.GrayText;
            this.label1.Location = new System.Drawing.Point(37, 53);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 29);
            this.label1.TabIndex = 51;
            this.label1.Text = "Casas";
            // 
            // lblOperV
            // 
            this.lblOperV.AutoSize = true;
            this.lblOperV.BackColor = System.Drawing.Color.DarkGray;
            this.lblOperV.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOperV.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblOperV.Location = new System.Drawing.Point(42, 401);
            this.lblOperV.Name = "lblOperV";
            this.lblOperV.Size = new System.Drawing.Size(211, 29);
            this.lblOperV.TabIndex = 50;
            this.lblOperV.Text = "Operación: Ventas";
            // 
            // lblTituloV
            // 
            this.lblTituloV.AutoSize = true;
            this.lblTituloV.BackColor = System.Drawing.Color.DarkGray;
            this.lblTituloV.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloV.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblTituloV.Location = new System.Drawing.Point(37, 20);
            this.lblTituloV.Name = "lblTituloV";
            this.lblTituloV.Size = new System.Drawing.Size(378, 29);
            this.lblTituloV.TabIndex = 49;
            this.lblTituloV.Text = "Viviendas/Casas y Departamentos";
            // 
            // lstTablaO
            // 
            this.lstTablaO.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaO.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaO.FormattingEnabled = true;
            this.lstTablaO.ItemHeight = 20;
            this.lstTablaO.Location = new System.Drawing.Point(629, 441);
            this.lstTablaO.Name = "lstTablaO";
            this.lstTablaO.Size = new System.Drawing.Size(352, 224);
            this.lstTablaO.TabIndex = 48;
            this.lstTablaO.Click += new System.EventHandler(this.lstTablaO_Click);
            // 
            // dtgViewTablaO
            // 
            this.dtgViewTablaO.AllowUserToOrderColumns = true;
            this.dtgViewTablaO.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dtgViewTablaO.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dtgViewTablaO.BackgroundColor = System.Drawing.Color.DarkGray;
            this.dtgViewTablaO.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgViewTablaO.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dtgViewTablaO.DefaultCellStyle = dataGridViewCellStyle3;
            this.dtgViewTablaO.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.dtgViewTablaO.Enabled = false;
            this.dtgViewTablaO.Location = new System.Drawing.Point(47, 441);
            this.dtgViewTablaO.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtgViewTablaO.Name = "dtgViewTablaO";
            this.dtgViewTablaO.ReadOnly = true;
            this.dtgViewTablaO.RowHeadersWidth = 51;
            this.dtgViewTablaO.RowTemplate.Height = 28;
            this.dtgViewTablaO.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dtgViewTablaO.Size = new System.Drawing.Size(576, 224);
            this.dtgViewTablaO.TabIndex = 47;
            // 
            // grpOper2
            // 
            this.grpOper2.Controls.Add(this.btnVenderDpto);
            this.grpOper2.Location = new System.Drawing.Point(1375, 91);
            this.grpOper2.Margin = new System.Windows.Forms.Padding(4);
            this.grpOper2.Name = "grpOper2";
            this.grpOper2.Padding = new System.Windows.Forms.Padding(4);
            this.grpOper2.Size = new System.Drawing.Size(196, 224);
            this.grpOper2.TabIndex = 46;
            this.grpOper2.TabStop = false;
            // 
            // btnVenderDpto
            // 
            this.btnVenderDpto.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnVenderDpto.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVenderDpto.FlatAppearance.BorderSize = 0;
            this.btnVenderDpto.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnVenderDpto.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVenderDpto.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVenderDpto.ForeColor = System.Drawing.Color.White;
            this.btnVenderDpto.Location = new System.Drawing.Point(21, 170);
            this.btnVenderDpto.Margin = new System.Windows.Forms.Padding(4);
            this.btnVenderDpto.Name = "btnVenderDpto";
            this.btnVenderDpto.Size = new System.Drawing.Size(167, 46);
            this.btnVenderDpto.TabIndex = 37;
            this.btnVenderDpto.Text = "Vender Dpto.";
            this.btnVenderDpto.UseVisualStyleBackColor = false;
            this.btnVenderDpto.Click += new System.EventHandler(this.btnVenderDpto_Click);
            // 
            // grpOper1
            // 
            this.grpOper1.Controls.Add(this.btnVentaCasa);
            this.grpOper1.Location = new System.Drawing.Point(580, 91);
            this.grpOper1.Margin = new System.Windows.Forms.Padding(4);
            this.grpOper1.Name = "grpOper1";
            this.grpOper1.Padding = new System.Windows.Forms.Padding(4);
            this.grpOper1.Size = new System.Drawing.Size(196, 224);
            this.grpOper1.TabIndex = 45;
            this.grpOper1.TabStop = false;
            // 
            // btnVentaCasa
            // 
            this.btnVentaCasa.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(39)))), ((int)(((byte)(57)))), ((int)(((byte)(80)))));
            this.btnVentaCasa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnVentaCasa.FlatAppearance.BorderSize = 0;
            this.btnVentaCasa.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(125)))), ((int)(((byte)(50)))));
            this.btnVentaCasa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnVentaCasa.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVentaCasa.ForeColor = System.Drawing.Color.White;
            this.btnVentaCasa.Location = new System.Drawing.Point(21, 170);
            this.btnVentaCasa.Margin = new System.Windows.Forms.Padding(4);
            this.btnVentaCasa.Name = "btnVentaCasa";
            this.btnVentaCasa.Size = new System.Drawing.Size(167, 46);
            this.btnVentaCasa.TabIndex = 37;
            this.btnVentaCasa.Text = "Vender Casa";
            this.btnVentaCasa.UseVisualStyleBackColor = false;
            this.btnVentaCasa.Click += new System.EventHandler(this.btnVentaCasa_Click);
            // 
            // lstTablaD
            // 
            this.lstTablaD.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaD.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaD.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lstTablaD.FormattingEnabled = true;
            this.lstTablaD.ItemHeight = 20;
            this.lstTablaD.Location = new System.Drawing.Point(796, 91);
            this.lstTablaD.Name = "lstTablaD";
            this.lstTablaD.Size = new System.Drawing.Size(572, 224);
            this.lstTablaD.TabIndex = 44;
            this.lstTablaD.Click += new System.EventHandler(this.lstTablaD_Click);
            // 
            // lstTablaC
            // 
            this.lstTablaC.BackColor = System.Drawing.Color.DarkGray;
            this.lstTablaC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstTablaC.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lstTablaC.FormattingEnabled = true;
            this.lstTablaC.ItemHeight = 20;
            this.lstTablaC.Location = new System.Drawing.Point(42, 91);
            this.lstTablaC.Name = "lstTablaC";
            this.lstTablaC.Size = new System.Drawing.Size(531, 224);
            this.lstTablaC.TabIndex = 40;
            this.lstTablaC.Click += new System.EventHandler(this.lstTablaC_Click);
            // 
            // lblComision
            // 
            this.lblComision.AutoSize = true;
            this.lblComision.BackColor = System.Drawing.Color.DarkGray;
            this.lblComision.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblComision.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lblComision.Location = new System.Drawing.Point(42, 667);
            this.lblComision.Name = "lblComision";
            this.lblComision.Size = new System.Drawing.Size(185, 24);
            this.lblComision.TabIndex = 64;
            this.lblComision.Text = "Comision por Ventas";
            // 
            // frmVenta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1576, 815);
            this.Controls.Add(this.pnlAcceso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmVenta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Operaciones: Venta de Inmuebles";
            this.pnlAcceso.ResumeLayout(false);
            this.pnlAcceso.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgViewTablaO)).EndInit();
            this.grpOper2.ResumeLayout(false);
            this.grpOper1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlAcceso;
        private System.Windows.Forms.ListBox lstTablaD;
        private System.Windows.Forms.ListBox lstTablaC;
        private System.Windows.Forms.GroupBox grpOper2;
        private System.Windows.Forms.Button btnVenderDpto;
        private System.Windows.Forms.GroupBox grpOper1;
        private System.Windows.Forms.Button btnVentaCasa;
        private System.Windows.Forms.ListBox lstTablaO;
        private System.Windows.Forms.DataGridView dtgViewTablaO;
        private System.Windows.Forms.Label lblOperV;
        private System.Windows.Forms.Label lblTituloV;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button butSalir;
        private System.Windows.Forms.Button btnEliminarOper;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblReservasC;
        private System.Windows.Forms.ListBox lstTablaR;
        private System.Windows.Forms.ListBox lstTablaOper;
        private System.Windows.Forms.Label lblComision;
    }
}