﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using capaNegocio;

namespace capaUsuario
{
    public partial class frmSucursal : Form
    {
        private Inmobiliaria iSuc;
        private int cantsuc;

        public frmSucursal()
        {
            iSuc = Inmobiliaria.Recuperar("Sucursal.dat");
            InitializeComponent();
            //Cargar List y DataView.
            CargarCompViewS();

            cantsuc = iSuc.CantSucursal();
        }

        private void btnSucursalC_Click(object sender, EventArgs e)
        {
            Sucursal s = null;
            frmClsSucursal agregar = new frmClsSucursal(s, true, cantsuc);
            CargarInfo(agregar);
        }
        private void CargarInfo(frmClsSucursal agregar)
        {
            agregar.ShowDialog();
            Sucursal suc = agregar.Suc;
            if (suc != null)
            {
                //Cargar el ListBox
                iSuc.AgregarSucursal(suc);

                //Cargar List y DataView.
                CargarCompViewS();
            }
        }
        private void btnSucursalE_Click(object sender, EventArgs e)
        {
            Sucursal s = (Sucursal)lstTablaS.SelectedItem;
            if (s != null)
            {
                iSuc.EliminarSucursal(s);

                //Cargar List y DataView.
                CargarCompViewS();
            }
            else
                MessageBox.Show("No selecciono un Cliente.");
        }
        private void btnSucursalA_Click(object sender, EventArgs e)
        {
            Sucursal s = (Sucursal)lstTablaS.SelectedItem;
            if (s != null)
            {
                frmClsSucursal agregar = new frmClsSucursal(s, false, cantsuc);
                agregar.ShowDialog();

                //Cargar List y DataView.
                CargarCompViewS();
            }
            else
                MessageBox.Show("No selecciono un Cliente.");
        }
        private void CargarCompViewS()
        {
            //Cargar ListBox.
            lstTablaS.DataSource = null;
            lstTablaS.DataSource = iSuc.ListaSucural;
            lstTablaS.ClearSelected();

            //Cargar DataGridView.
            dtgViewTablaS.DataSource = null;
            dtgViewTablaS.DataSource = iSuc.ListaSucural;
            dtgViewTablaS.ClearSelection();
        }
        private void FPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
                      
        }
        private void btnClose_Click(object sender, EventArgs e)
        {            
            if (iSuc.guardarSucursal() == false)
                MessageBox.Show("ERROR AL INTENTAR GAURDAR");
        }
        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
