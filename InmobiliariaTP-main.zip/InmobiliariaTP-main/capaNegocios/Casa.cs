﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace capaNegocio
{
    [Serializable]
    public class Casa : Vivienda
    {
        private int m2Terreno;

        //Constructor de la clase 
        public Casa(string c, int n, string l, string p, string pro, int m2c, int m2t, string id) 
                    : base(c, n, l, p, pro, m2c, id)
        {
            this.m2Terreno = m2t;
        }
        //Propiedades de los atributos
        public int M2Terreno
        {
            set { m2Terreno = value; }
            get { return this.m2Terreno; }
        }
        //20% del valor considerado por Sucursal.
        public double Costo_m2_terreno(double c)
        {
            return m2Terreno * (c * 0.2);
        }
        public override double Costo_Total(double c)
        {
            return base.Costo_Total(c) + this.Costo_m2_terreno(c);
        }
        public override string ToString()
        {
            return calle + " " + nro + ", " +localidad + ", " + partido + ", " + provincia + ", " + id;
        }
    }
}
