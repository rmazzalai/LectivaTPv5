﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using capaNegocio;

namespace capaNegocio
{
    [Serializable]
    public class Reserva
    {
        private DateTime fecha;
        private int codReserva;
        private Casa casaReserva;
        private Dpto dptoReserva;
        private Cliente clienteReserva;
        private int diasReserva;

        //Constructor de la clase
        public Reserva(DateTime d, int cod, Casa c, Dpto dpto, Cliente cli, int dias)
        {
            this.Fecha = d;
            this.CodReserva = cod;
            this.CasaReserva = c;
            this.DptoReserva = dpto;
            this.ClienteReserva = cli;
            this.DiasReserva = dias;
        }
        public DateTime Fecha 
        {
            get { return fecha; }
            set { this.fecha = value; } 
        }

        public int CodReserva 
        {
            get { return codReserva; }
            set { this.codReserva = value; }
        }

        public Casa CasaReserva
        {
            get { return casaReserva; }
            set { casaReserva = value;}         
        }

        public Dpto DptoReserva
        {
            get { return dptoReserva; }
            set { this.dptoReserva = value; } 
        }

        public Cliente ClienteReserva 
        {
            get { return clienteReserva; }
            set { this.clienteReserva = value; } 
        }

        public int DiasReserva 
        {
            get { return this.diasReserva; }
            set { this.diasReserva = value; }
        }

        public override string ToString()
        {

            var vivienda = " ";
            
            if(casaReserva != null)
            {
                vivienda = casaReserva.Id + " DIRECCION: " + casaReserva.Calle + " " + casaReserva.Nro + ", "+ casaReserva.Localidad + ", "+ casaReserva.Provincia;
            }
            else
                if(dptoReserva !=null )
                 {
                    vivienda = dptoReserva.Id + " DIRECCION: " + dptoReserva.Calle + " " + dptoReserva.Nro + " PISO:" + dptoReserva.NroPiso+ " DPTO: " + dptoReserva.NroDpto + ", " + dptoReserva.Localidad + ", " + dptoReserva.Provincia;
            }
            
            return $" ={codReserva}= {fecha.ToString("dd/MM/yyyy")} {clienteReserva.Apellido} {clienteReserva.Nombre} {vivienda}";
    
        }

    }
}
